</div>

<div id="footer">
<div class="notices">
<?php bloginfo('name'); ?>  <?php echo date('Y');?>. All rights reserved    |    Designed by <a href="http://www.dizenoco.com">Dizeno Co</a>    |    Powered by <a href="http://wordpress.org/">WordPress</a>

<a href="http://validator.w3.org/check?uri=referer"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/w3c-xhtml.jpg" alt="Valid XHTML 1.0 Transitional" /></a>
<a href="http://jigsaw.w3.org/css-validator/check/referer"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/w3c-css.jpg" alt="Valid CSS!" /></a>

</div>
</div>

<?php wp_footer(); ?>

</body>
</html>