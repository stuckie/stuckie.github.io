<?php
if ( function_exists('register_sidebar') )
    register_sidebar(array(
        'name' => 'Sidebar',
        'before_widget' => '',
        'after_widget' => '',
        'before_title' => '<h4>',
        'after_title' => '</h4>',
    ));

/*this function that truncates titles to specified number of characters*/
function the_title2($before = '', $after = '', $echo = true, $length = false) {
    $title = get_the_title();
    if ( $length && is_numeric($length) ) {
		$title = mb_substr( $title, 0, $length, 'UTF-8' );
	}
    if ( strlen($title)> 0 ) {
		if ( strlen($title) == $length ) $title = apply_filters('the_title2', $before . $title . $after, $before, $after);
        if ( $echo ) echo $title;
        else return $title;
	}
}

?>